#! /bin/bash
python3 benchmark_models.py
